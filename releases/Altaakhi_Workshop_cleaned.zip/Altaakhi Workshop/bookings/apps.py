from django.apps import AppConfig


class BookingsConfig(AppConfig):
    name = "bookings"
