# Ensure Service model is registered for Django
